PYTHON ACTIVITY-BASED LEARNING - VIKAS

Student: Vikas
Roll Number: 26000609
Branch: CSE

The folder python_programs contains the 10 Python source files used in the report.
Run a file from the VS Code terminal using:
    python case_01.py

Important:
The report's VS Code-style execution panels are illustrative and are not real screenshots
from the student's computer. Open and run each .py file in VS Code, capture your own
screenshots, and replace the illustrative panels before final submission.
