text = "aaabbccccd"

if text == "":
    print("Empty input")
else:
    result = ""
    count = 1

    for i in range(1, len(text)):
        if text[i] == text[i - 1]:
            count = count + 1
        else:
            result = result + text[i - 1] + str(count)
            count = 1

    result = result + text[-1] + str(count)

    print("Original text:", text)
    print("Compressed text:", result)
    print("Original length:", len(text))
    print("Compressed length:", len(result))
