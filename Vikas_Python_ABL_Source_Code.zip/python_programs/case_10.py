days = ["Monday", "Tuesday", "Wednesday"]
prepared = [100, 120, 80]
served = [90, 100, 76]

total_leftover = 0
limit = 10

print("FOOD WASTE REPORT")

for i in range(len(days)):
    leftover = prepared[i] - served[i]
    percentage = leftover / prepared[i] * 100
    total_leftover = total_leftover + leftover

    print(days[i])
    print("Leftover meals:", leftover)
    print("Wastage:", round(percentage, 2), "%")

    if percentage > limit:
        print("Wastage exceeds limit")
    else:
        print("Within limit")
    print()

print("Total leftover meals:", total_leftover)
