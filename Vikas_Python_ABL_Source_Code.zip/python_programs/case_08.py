names = ["Asha", "Ravi", "Kiran"]
subjects = ["Python", "Maths", "English"]

marks = [
    [85, 78, 90],
    [72, 88, 80],
    [92, 90, 85]
]

highest_total = 0
topper = ""

print("STUDENT MARKS")

for i in range(len(marks)):
    total = 0
    for j in range(len(marks[i])):
        total = total + marks[i][j]

    print(names[i], "Total:", total)

    if total > highest_total:
        highest_total = total
        topper = names[i]

print("SUBJECT TOTALS")
for j in range(len(subjects)):
    subject_total = 0
    for i in range(len(marks)):
        subject_total = subject_total + marks[i][j]
    print(subjects[j], ":", subject_total)

print("Topper:", topper)
print("Highest total:", highest_total)
