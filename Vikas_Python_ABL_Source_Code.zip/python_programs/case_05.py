password = "Hello@123"

has_upper = False
has_lower = False
has_digit = False
has_special = False

for ch in password:
    if ch >= "A" and ch <= "Z":
        has_upper = True
    elif ch >= "a" and ch <= "z":
        has_lower = True
    elif ch >= "0" and ch <= "9":
        has_digit = True
    elif ch in "@#$!":
        has_special = True

valid = True
print("PASSWORD VALIDATION")

if len(password) < 8:
    print("Failed: Minimum 8 characters required")
    valid = False
if not has_upper:
    print("Failed: Add an uppercase letter")
    valid = False
if not has_lower:
    print("Failed: Add a lowercase letter")
    valid = False
if not has_digit:
    print("Failed: Add a digit")
    valid = False
if not has_special:
    print("Failed: Add @, #, $ or !")
    valid = False

if valid:
    print("Password meets all rules")
else:
    print("Password does not meet the policy")
