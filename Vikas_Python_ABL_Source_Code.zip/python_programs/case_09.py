products = [
    (101, "Pen", 10, 20),
    (102, "Notebook", 50, 3),
    (103, "Pencil", 5, 15),
    (104, "Eraser", 8, 2)
]

total_value = 0

print("PRODUCT STOCK REPORT")

for product in products:
    product_id, name, price, quantity = product

    if price < 0 or quantity < 0:
        print("Invalid record:", name)
    else:
        value = price * quantity
        total_value = total_value + value

        print(name, "Stock value: Rs.", value)

        if quantity < 5:
            print("Reorder needed:", name)

print("Total inventory value: Rs.", total_value)
