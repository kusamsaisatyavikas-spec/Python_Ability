feedback = [
    "The class is good and helpful",
    "The topic is difficult and boring",
    "The explanation is clear"
]

positive_words = ["good", "excellent", "helpful", "clear", "interesting"]
negative_words = ["bad", "poor", "confusing", "difficult", "boring"]

for sentence in feedback:
    words = sentence.lower().split()
    positive_count = 0
    negative_count = 0

    for word in words:
        if word in positive_words:
            positive_count = positive_count + 1
        elif word in negative_words:
            negative_count = negative_count + 1

    score = positive_count - negative_count

    if score > 0:
        result = "Positive"
    elif score < 0:
        result = "Negative"
    else:
        result = "Neutral"

    print("Feedback:", sentence)
    print("Positive words:", positive_count)
    print("Negative words:", negative_count)
    print("Result:", result)
    print()
