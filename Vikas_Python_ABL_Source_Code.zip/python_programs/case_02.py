total_classes = 40
attended_classes = 26
required = 75

if total_classes <= 0 or attended_classes < 0 or attended_classes > total_classes:
    print("Invalid attendance details")
else:
    percentage = attended_classes / total_classes * 100
    print("Current attendance:", round(percentage, 2), "%")

    if percentage >= required:
        print("Status: Eligible")
        print("Extra classes needed: 0")
    else:
        extra = 0
        while (attended_classes + extra) / (total_classes + extra) * 100 < required:
            extra = extra + 1

        print("Status: Not eligible yet")
        print("Extra classes to attend:", extra)
        print("Projected attendance:", round((attended_classes + extra) / (total_classes + extra) * 100, 2), "%")
