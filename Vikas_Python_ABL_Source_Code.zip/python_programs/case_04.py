rows = 5

if rows < 1 or rows > 9:
    print("Enter rows from 1 to 9")
else:
    print("NUMBER PYRAMID")
    for i in range(1, rows + 1):
        for space in range(rows - i):
            print(" ", end=" ")

        for j in range(1, i + 1):
            print(j, end=" ")

        for j in range(i - 1, 0, -1):
            print(j, end=" ")

        print()
