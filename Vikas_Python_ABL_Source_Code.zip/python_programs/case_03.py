balance = 5000

transactions = [
    ("DEPOSIT", 2000),
    ("WITHDRAW", 1500),
    ("WITHDRAW", 7000),
    ("DEPOSIT", 500),
    ("WITHDRAW", 1000)
]

deposit_count = 0
withdrawal_count = 0
rejected_count = 0

for transaction in transactions:
    action, amount = transaction

    if amount <= 0:
        print("Invalid amount:", amount)
        rejected_count = rejected_count + 1
    elif action == "DEPOSIT":
        balance = balance + amount
        deposit_count = deposit_count + 1
    elif action == "WITHDRAW":
        if amount <= balance:
            balance = balance - amount
            withdrawal_count = withdrawal_count + 1
        else:
            print("Insufficient balance:", amount)
            rejected_count = rejected_count + 1
    else:
        print("Invalid transaction:", action)
        rejected_count = rejected_count + 1

print("ATM TRANSACTION SUMMARY")
print("Final balance: Rs.", balance)
print("Deposits accepted:", deposit_count)
print("Withdrawals accepted:", withdrawal_count)
print("Rejected transactions:", rejected_count)
